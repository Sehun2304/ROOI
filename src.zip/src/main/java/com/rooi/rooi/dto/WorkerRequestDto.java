package com.rooi.rooi.dto;

import lombok.Getter;

@Getter
public class WorkerRequestDto {
    private String worker;
}

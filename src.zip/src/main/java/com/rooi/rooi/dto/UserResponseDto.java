package com.rooi.rooi.dto;

public class UserResponseDto {
}

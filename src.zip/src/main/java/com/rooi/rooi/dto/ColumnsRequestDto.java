package com.rooi.rooi.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
public class ColumnsRequestDto {
    Long boardId;
    String title;
}

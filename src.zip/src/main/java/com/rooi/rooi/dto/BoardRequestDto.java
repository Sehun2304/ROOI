package com.rooi.rooi.dto;

import lombok.Getter;

@Getter
public class BoardRequestDto {
	private String title;
	private String contents;
	private String color;
}

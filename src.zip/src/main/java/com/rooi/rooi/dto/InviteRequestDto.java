package com.rooi.rooi.dto;

import lombok.Getter;

@Getter
public class InviteRequestDto {
	public String inviteUser;
}
